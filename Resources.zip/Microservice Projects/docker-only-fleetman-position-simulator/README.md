# fleetman-position-simulator
From the VirtualPairProgrammers.com Microservices Training Course - a toy microservice that generates fake streams of position data, representing trucks/lorries on a delivery route.

This code is not production standard - it is intended merely to generate some interesting test data.

See the full course and lots more amazing stuff at VirtualPairProgrammers.com.

